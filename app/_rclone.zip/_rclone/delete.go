package _rclone

import "github.com/anotherhope/rcloud/app/internal"

func Delete(d *internal.Repository) string {

	//

	return ""
}

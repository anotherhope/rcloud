package _rclone

import "github.com/anotherhope/rcloud/app/internal"

func Copy(d *internal.Repository) string {

	//

	return ""
}
